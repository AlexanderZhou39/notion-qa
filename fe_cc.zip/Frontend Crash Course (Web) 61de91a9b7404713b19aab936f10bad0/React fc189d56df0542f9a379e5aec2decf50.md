# React

> Love it or hate it, it’s popular
> 

---

[React Docs Beta](https://beta.reactjs.org/)

Definitely check this out. Amazing documentation for all levels.

---

## Setup

[Picking The Right Starting Tool](React%20fc189d56df0542f9a379e5aec2decf50/Picking%20The%20Right%20Starting%20Tool%20022e728ecf84472e8f35c9b1edb76497.md)

## Knowledge

[Component Lifecycle](React%20fc189d56df0542f9a379e5aec2decf50/Component%20Lifecycle%204c8b891e3261445ab188133cfb30953e.md)

[useState, useRef, & useEffect](React%20fc189d56df0542f9a379e5aec2decf50/useState,%20useRef,%20&%20useEffect%20009b42e51d4444cdb7c354577738e764.md)

## Organization

[File Structure](React%20fc189d56df0542f9a379e5aec2decf50/File%20Structure%20ff60f772453f4428bc2e205f48252861.md)

[Component File](React%20fc189d56df0542f9a379e5aec2decf50/Component%20File%20ec8c9aec2a2948aca5fd6fc1ad53d9f2.md)

## Techniques

[Routing](React%20fc189d56df0542f9a379e5aec2decf50/Routing%20bec42cf9e78243e8b488d8fd1b86ccdb.md)

[API Interaction](React%20fc189d56df0542f9a379e5aec2decf50/API%20Interaction%20e984f10b2aef453a8b1b5133ceb19bd0.md)

[Lazy Loading](React%20fc189d56df0542f9a379e5aec2decf50/Lazy%20Loading%2055874e662e2b424d9ac3c2405b90ac35.md)

[Typescript with React](React%20fc189d56df0542f9a379e5aec2decf50/Typescript%20with%20React%20cf56f8d9ac04481890cea2942e51e74a.md)