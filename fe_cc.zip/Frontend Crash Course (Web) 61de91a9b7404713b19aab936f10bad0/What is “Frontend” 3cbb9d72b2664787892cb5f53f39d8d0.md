# What is “Frontend”?

> starting from the basics
> 

---

Suppose you visit a fancy restaurant. A comely waiter guides you to your seat, where you are greeted with their Friday night specialty menu. Between the ten dishes, you decide to pick something safe and light. The waiter scribbles your order on their notepad before heading off into the kitchen, presumably to communicate the new order to the chefs. After scrolling on your phone for a while, you are suddenly greeted with a warm smell as the food is placed onto your table. 

Now suppose we retold this from another perspective:

On your laptop, you open up your browser and enter in a link to a website. You are greeted with the website’s home page, and between the ten links in the navigation menu, you click the first one. The browser registers your request to view the page connected to the link and sends it to the website’s server. Then within a few hundred milliseconds, the server responds, and you are greeted with the new page. 

In other words, a website works similarly to a restaurant, and the frontend to a website is the same as what a customer experiences at a restaurant. The frontend is essentially the aspects of an app/service that the user interacts with. This is usually just the pages of a website/app. 

Here are more slightly-oversimplified comparisons from the analogy:

| Restaurant | Website |
| --- | --- |
| Waiter | The user’s browser (Chrome, Internet Explorer, Firefox, etc.) |
| Chefs | Backend (server, database, etc.) |
| Menu | Webpage (HTML, CSS, JS) |
| Food | Information/service |
| Dining experience | User experience (UX) |